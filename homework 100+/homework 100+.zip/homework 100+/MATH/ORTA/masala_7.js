let random = Math.floor(Math.random() * 100); 
console.log(random % 2 === 0);